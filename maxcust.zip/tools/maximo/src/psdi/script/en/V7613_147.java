/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-U18
 *
 * (C) COPYRIGHT IBM CORP. 2021
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been
 * deposited with the U.S. Copyright Office.
 */
package psdi.script.en;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.Properties;

import psdi.script.AutoUpgradeTemplate;
import psdi.util.MXCipherX;
import psdi.util.MXProperties;

public class V7613_147 extends AutoUpgradeTemplate {

	public V7613_147(Connection con) throws Exception {
		super(con);
	}

	public V7613_147(Connection con, PrintStream ps) throws Exception {
		super(con, ps);
	}

	public V7613_147(Connection con, HashMap params, PrintStream ps) throws Exception {
		super(con, params, ps);
	}
	
	

	@Override
	protected void process() throws Exception {
		super.process();
		
		InputStream in = new FileInputStream(getPropDir() + java.io.File.separator + "maximo.properties") ;
		Properties properties = MXProperties.loadProperties(in, false);
		
		String providerTest = properties.getProperty("mxe.security.provider");
		String algTestX = properties.getProperty("mxe.security.cryptox.algorithm");
		String modeTestX = properties.getProperty("mxe.security.cryptox.mode");
		String paddingTestX = properties.getProperty("mxe.security.cryptox.padding");
		String keyTestX = properties.getProperty("mxe.security.cryptox.key");
		String specTestX = properties.getProperty("mxe.security.cryptox.spec");
		String modTestX = properties.getProperty("mxe.security.cryptox.modulus");
		MXCipherX cipherX = new MXCipherX(algTestX, modeTestX, paddingTestX, keyTestX, specTestX, modTestX, providerTest);

		String[] users =  new String[] {"fitz"};
		try (PreparedStatement s = con.prepareStatement("update maxuser set password=? where userid=?")) {
			for (String userid : users) {
				byte[] password = cipherX.encData(userid);
				s.setBytes(1, password);
				s.setString(2, userid.toUpperCase());
				s.executeUpdate();
			}
		} finally {
			executeSql("commit");
		}
	}

}
