# Installing Maximo Mobile Package

## 1. Unzip the **maximomobile.zip** to your **MAXIMO_ROOT_FOLDER**.

## 2. Running Scripts:
###### The database scripts from Maximo Mobile are placed at:
	- MAXIMO_ROOT_FOLDER/tools/maximo/en/maximomobile/
	- MAXIMO_ROOT_FOLDER/tools/maximo/en/graphiteapps/
	
###### Run **runscriptfile** tool from MAXIMO_ROOT_FOLDER/tools/maximo/internal
```
	WINDOWS
	> runscriptfile.bat -cmaximomobile -fALL
	> runscriptfile.bat -cgraphiteapps -fALL
```
```
	Shell
	> ./runscriptfile.sh -cmaximomobile -fALL
	> ./runscriptfile.sh -cgraphiteapps -fALL
```

###### Run **pkginstall** tool from MAXIMO_ROOT_FOLDER/tools/maximo

```
	WINDOWS
	> pkginstall.bat
```
```
	Shell
	> ./pkginstall.sh
```

## 3. Maximo Graphite Applications import process

###### The Graphite Applications import process can be done running the **updatedb**. Note that all files having .zip extension will be imported to the Maximo Mobile tables (MAXMOBILEAPP/MAXAPPDATA). If any of .zip file contained in the below folder is not intented to be imported as mobile application you should remove it before run updatedb command.
```
	- MAXIMO_ROOT_FOLDER/tools/maximo/en/graphite/apps/
```
###### Run updatedb from MAXIMO_ROOT_FOLDER/tools/maximo
```
	WINDOWS
	> updatedb.bat
```
```
	Shell
	> updatedb.sh
```

## 4. Configuring Maximo Mobile servlet to maximo.ear

##### Maximo Mobile servlet is required as part of **maximo.ear**. These commands must be performed **before** maximo.ear generation.

###### The scripts used to perform this task are placed at:
	- MAXIMO_ROOT_FOLDER/deployment

###### Run **includemobilemodule**
```
	WINDOWS
	> includemobilemodule.cmd
```
```
	Shell
	> includemobilemodule.sh
```

## 5. Proceed to standard maximo.ear and maximo-x.war creation and deployment process




## New system properties added by Mobile to Inspections:
mxe.mobile.inspection.mobilefeatures
  Enable new features in Manage Inspection Forms that are not supported in the current Conduct an Inspection work center. Remember that Mobile Inspections is also
  available in a web browser and is the natural replacement for the existing work center.

mxe.app.workorder.InspectionBatchRecord
  Defines if a batch card will be created for each work order. This batch card is not yet supported in Maximo Mobile

mxe.app.workorder.StatusToCreateInspection
  Defines on which work order status the inspection result will be created. It supports multiple internal status value separated by comma. Until that, the form is editable in the WO

mxe.app.inspection.UpdatePendingResults
  Update existing pending results based on last form revisions


  
 



