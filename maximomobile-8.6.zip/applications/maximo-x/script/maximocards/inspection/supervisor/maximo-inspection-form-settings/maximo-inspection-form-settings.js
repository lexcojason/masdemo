/*
 * @license
 * Licensed Materials - Property of IBM
 * 5724-U18
 * Copyright IBM Corporation. 2016,2019
 */
Polymer({
	is: 'maximo-inspection-form-settings',

  	behaviors: [BaseComponent, HTMLEncoder],

  	listeners: {
  	  'addElement'              : '_addSelected',
  	  'removeElement'           : '_removeSelected',
      'optionSelectedChanged'   : '_optionSelectedChanged',
      'selectedSelectedChanged' : '_selectedSelectedChanged',
      'reorderChosen'           : '_orderChanged'
  	},

    properties: {

      /**
       * Current form revision
       */
      formRevision: {
        type: Object,
        value: {}
      },

      /**
       * Copy of form revision
       */
      lightweightForm: {
        type: Object,
        value: {}
      },

      /**
       * Flag to indicate whether a change happened
       */
      hasChanged: {
        type: Boolean,
        value: false,
        readOnly: true,
      },

      /**
       * List of launch points
       */
      availableAutoscripts: {
        type: Array,
        value: []
      },

      /**
       * List of selected launch points
       */
      chosenAutoScripts: {
        type: Array,
        value: []
      },

      /**
       * Auto Script filter
       */
      collectionFilter: {
        type: Array,
        value: function() {
          var encodedStr = encodeURIComponent('OSACTION.MXAPIINSP%');
          return [
            {
              filtertype: 'SIMPLE', field: 'autoscript',
              availablevalues: [ {value: encodedStr, selected: true} ]
            },{
              filtertype: 'SIMPLE', field: 'active',
              availablevalues: [ {value: 'true', selected: true} ]
            }];
        }
      },

      /**
       * Flag whether user can perform updates
       */
      readOnlyMode: {
        type: Boolean,
        value: false
      },
      
    },

    ready : function(){
  	},

  	attached: function() {
  	},

  	/**
     * audioguided observer
     */
    _audioGuidedChanged: function(event) {

      if (!this.lightweightForm) {
        return;
      }
      this.lightweightForm.audioguided = event.detail;
      // Whatever changes set the var to true
      this._setHasChanged(this.verifyChanges());
    },

    /**
     * readconfirmation observer
     */
    _readConfirmationChanged: function(event) {
      if (!this.lightweightForm) {
        return;
      }
      this.lightweightForm.readconfirmation = event.detail;
      // Whatever changes set the var to true
      this._setHasChanged(this.verifyChanges());
    },

    /**
     * Look for changes between original list and new list
     */
    _hasSelectedScriptsChanged: function() {
      var hasChanged = false;
      var originalList = this.formRevision.inspformscript || [];
      var newList = this.lightweightForm.inspformscript || [];

      // Different size
      if (originalList.length !== newList.length){
        hasChanged = true;
        
      } else {
        for (var i = 0; i < originalList.length; i++) {
          var newListItem = newList[i];
          // Out of sequence
          if (newListItem.href !== originalList[i].href) {
            hasChanged = true;
            break;
          } else if (newListItem.hasOwnProperty('_action')) {
            hasChanged = true;
            break;
          }
        }
      }

      return hasChanged;
    },

    /**
     * Include selected script into inspformscript
     */
    addScript: function(script) {

      if (!this.lightweightForm.inspformscript) {
        this.lightweightForm.inspformscript = [];
      }

      var formScripts = this.lightweightForm.inspformscript;
      var formScriptNames = formScripts.map(function(ele){
        return ele.autoscript;
      });

      // Check if new script exists in existing script list
      var indexFound = formScriptNames.indexOf(script.autoscript);
      if (indexFound > -1) {
        formScripts[indexFound]._action = 'Update';
      } else {
        var formScript = this.buildFormScript(script);
        formScripts.push(formScript);
      }
    },

    /**
     * Remove selected script from inspformscript
     */
    removeScript: function(script) {

      var formScripts = this.lightweightForm.inspformscript;
      var formScriptNames = formScripts.map(function(ele){
        return ele.autoscript;
      });

      // Check if new script exists in existing script list
      var indexFound = formScriptNames.indexOf(script.autoscript);

      if (indexFound > -1) {
        // Update action to delete
        formScripts[indexFound]._action = 'Delete';
        // Move item to the end of the list
        formScripts.push(formScripts.splice(indexFound, 1)[0]);
      }

    },

    /**
     * Build element based on script
     */
    buildFormScript: function(script) {

      var form = this.lightweightForm;

      var formScript = {
        autoscript: script.autoscript,
        inspformnum: form.inspformnum,
        orgid: form.orgid,
        revision: form.revision,
        _action: 'Add'
      };
      
      if (form.siteid) {
        formScript.siteid = form.siteid;
      }

      return formScript;
    },

    /**
     * Set inspformscript order based on datalist selection
     */
    setScriptsSequence: function() {
      var datasetScripts = this.chosenAutoScripts;
      var formScripts = this.lightweightForm.inspformscript;
      var formScriptNames = formScripts.map(function(ele){
        return ele.autoscript;
      });

      // Iterate over datasetScripts
      // Found correspondent formScript and set its sequence attribute to datasetScript index+1
      for (var i = 0; i < datasetScripts.length; i++) {
        var formScriptIndex = formScriptNames.indexOf(datasetScripts[i].autoscript);
        formScripts[formScriptIndex].sequence = i+1;
      }

    },

    /**
     * Compare attribute modifications
     */
    verifyChanges: function() {
      var hasChanged = false;
    
      if (this.lightweightForm.readconfirmation !== this.formRevision.readconfirmation) {
        hasChanged = true;
      } else if (this.lightweightForm.audioguided !== this.formRevision.audioguided) {
        hasChanged = true;
      } else if (this._hasSelectedScriptsChanged()) {
        hasChanged = true;
      }

      return hasChanged;
    },

    /**
     * Extract required properties from original form revision
     */
    copyFormRevision: function(formRevision) {

      var form = JSON.parse(JSON.stringify(formRevision));
      
      var copy = {
          readconfirmation: form.readconfirmation || false,
          audioguided: form.audioguided || false,
          href: HTMLEncoder.encode(form.href) || null,
          inspformnum: form.inspformnum || null,
          revision: form.revision || null,
          orgid: form.orgid || null,
          siteid: form.siteid || null
      };

      if (form.inspformscript) {
        copy.inspformscript = form.inspformscript;
      }
      return copy;
    },

    /**
     * Complete button handler
     */
    _complete: function(event) {

      // ReadOnly mode
      if (this.readOnlyMode) {
        this.closeMe();
        return;
      }

      // Check if any change
      if (!this.hasChanged) {
        this.closeMe();
        return;
      }

      // Get record copy with changed values
      var recordCopy = this.lightweightForm;

      $M.toggleWait(true);

      //Update record
      var req = this.updateRecord(recordCopy);
      req.then( function(response) {

        this.saveMe(response);
        $M.toggleWait(false);

      }.bind(this), function(reason){
        console.log(reason);
        $M.toggleWait(false);
      });
      
    },

  	/**
  	 * Initial setup
  	 * Script options and buttons
  	 */
  	setUp: function(formRevision) {

  	  $M.toggleWait(true);

  	  // Enable buttons that might be previously disabled
  	  this.setReadOnlyMode(false);

  	  //this.resetSettings();
  	  var request = this.requestAutoScripts();

      request.then(function(response){
        // Set values on inputs

        // copy collection to variable
        var tempAvailableAutoscripts = JSON.parse(JSON.stringify(this.autoscriptSet));

        // Sort scripts based on sequence attribute
        if (formRevision.inspformscript) {
          formRevision.inspformscript.sort(function(a, b) {
            return a.sequence - b.sequence;
          });
        }

        // Copy form required properties
        this.lightweightForm = this.copyFormRevision(formRevision);
        this.formRevision = formRevision;

        // copy saved scripts to variable
        this.chosenAutoScripts = this.moveSavedScriptsToDataList(
            this.lightweightForm.inspformscript, tempAvailableAutoscripts);

        this.availableAutoscripts = tempAvailableAutoscripts;

        // Exporting values to local properties
        this.$.readConfirmationCheckbox.checked = this.lightweightForm.readconfirmation;
        this.$.audioGuidedCheckbox.checked      = this.lightweightForm.audioguided;

        // Reset change observer
        this._setHasChanged(false);

        this.setupDataListButtons();

        var status = formRevision.status_maxvalue;
        // ReadOnly mode
        if (status !== 'DRAFT' && status !== 'PNDREV') {
          this.setReadOnlyMode(true);
        }

        $M.toggleWait(false);
      }.bind(this), function(error){
        $M.toggleWait(false);
      });

  	},

  	/**
  	 * Adjust components to read only mode parameter
  	 */
  	setReadOnlyMode: function(isReadOnly) {
  	  
  	  this.readOnlyMode = isReadOnly;

  	  this.$.readConfirmationCheckbox.readonly = isReadOnly;
  	  this.$.audioGuidedCheckbox.readonly = isReadOnly;

  	  this.$.cancel.hidden = isReadOnly;

  	  if (isReadOnly) {
 		this.$.resetButton.setAttribute('disabled', 'true');
        this.$.addActions.setAttribute('disabled', 'true');
                this.$.selectiondatalist.removeEvent = null;
  	  } else {
  	    this.$.resetButton.removeAttribute('disabled');
        this.$.addActions.removeAttribute('disabled');
  	  }
  	  
  	  this.$.selectiondatalist.refresh();
  	},

  	/**
  	 * Set buttons status
  	 */
  	setupDataListButtons: function() {

  	  // Clear datalists selection
  	  this.$.optionsdatalist.clearSelected();
  	  this.$.selectiondatalist.clearSelected();

  	  // Disable add button
  	  this.$.addActions.setAttribute('disabled', 'true');

  	  if (this.chosenAutoScripts.length) {
  	    this.$.resetButton.removeAttribute('disabled');
  	  } else {
  		this.$.resetButton.setAttribute('disabled', 'true');
  	  }

  	},

  	/**
  	 * Copy saved scripts to chosen datalist
  	 */
  	moveSavedScriptsToDataList: function(savedScripts, availableScripts){
  	  var list = [];
  	  if (savedScripts) {
    	  for (var savedS of savedScripts) {
    	    var ind = availableScripts.findIndex(function(ele){ return ele.autoscript === savedS.autoscript; });
    	    if (ind > -1) {
    	      list.push(JSON.parse(JSON.stringify(availableScripts[ind])));
    	      availableScripts.splice(ind, 1);
    	    }
    	  }
  	  }

  	  return list;
  	},

  	/**
  	 * drag handler selected to another list
  	 */
  	_addBtnSelected: function(event) {
  	  this.addSelected();
  	},

  	/**
  	 * add handler selected
  	 */
  	_addSelected: function(event) {
  	  this.addSelected();
    },

  	/**
  	 * Add items to selection list
  	 */
  	addSelected: function() {
  	  var index = -1;
      var array = this.chosenAutoScripts;
      var records = this.$.optionsdatalist._selectedRecords;
      var added = false;

      if (this.readOnlyMode) {
        return;
      }

      records.forEach(function(record){

        if (!this.isDuplicated(record, array)){
          if(index>=0){
            array.splice(index, 0, record);
            index++;
          } else {
            array.push(record);
          }
          this.removeOption(record);
          this.addScript(record);
          added = true;
        }
        
      }.bind(this));

      if(added){
        this.$.optionsdatalist.refresh();
        this.$.selectiondatalist.refresh();
        //this.$.selectedrolessearch.clear(true);
        this.setScriptsSequence();
        this._setHasChanged(this.verifyChanges());
        this.setupDataListButtons();
      }
  	},

  	/**
     * Remove selected from selection list 
     */
    _removeSelected: function(event) {

      var array = this.chosenAutoScripts;
      var recordsToDelete = event.detail;
      var self = this;

      if (this.readOnlyMode) {
        return;
      }

      if(recordsToDelete.length === 0){
        return array;
      }
      var tempList = JSON.parse(JSON.stringify(array));
      var removed = 0;
      array.forEach(function(picked,index){
        recordsToDelete.forEach(function(record){
          if(picked.href === record.href){
            tempList.splice(index-removed, 1);
            removed++;
            self.addOption(record);
            self.removeScript(record);
          }
        });
      });
      
      if(removed){
        this.$.optionsdatalist.refresh();
        this.$.selectiondatalist.refresh();
        this.set('chosenAutoScripts', tempList);
        this.setScriptsSequence();
        this._setHasChanged(this.verifyChanges());
        this.setupDataListButtons();
      }

    },

    /**
     * Add option back to available options list
     */
    addOption: function(record) {
      this.availableAutoscripts.push(record);
    },

    /**
     * Remove option from available options list
     */
    removeOption: function(record) {
      
      var recordIndex = this.availableAutoscripts.findIndex(function(element, index, array){
        return element.autoscript === record.autoscript;
      });

      if (recordIndex > -1) {
        this.availableAutoscripts.splice(recordIndex, 1);
      }
    },

  	/**
  	 * Check duplicated records
  	 */
  	isDuplicated: function(element, list) {
  	  var filtered = list.filter(function(listItem){
  	    return listItem.href === element.href;
  	  });

  	  return Boolean(filtered.length);
  	},

  	/**
  	 * restore all options to available scripts
  	 */
  	resetOptions: function() {
  	  // copy collection to variable
      this.availableAutoscripts = JSON.parse(JSON.stringify(this.autoscriptSet));
  	},

  	/**
  	 * Reset list of chosen options
  	 */
  	resetChosen: function(e){
  	  for (var chosenScript of this.chosenAutoScripts) {
  	    this.removeScript(chosenScript);
  	  }
  	  this.resetOptions();
  	  this._setHasChanged(this.verifyChanges());
      this.set('chosenAutoScripts', []);
      this.$.optionsdatalist.refresh();
      this.$.selectiondatalist.refresh();
      this.setupDataListButtons();
    },

    /**
     * Order formscripList based on modelList order
     */
    reorderList: function(modelList, formScriptList) {

      // Iterate over model list
      for (var i = 0; i < modelList.length; i++) {
        var modelItem = modelList[i];

        // While positions don't match 
        while (modelItem.autoscript !== formScriptList[i].autoscript) {

          // Create map with autoscriptname and find the index of model
          var foundIndex = formScriptList.map(function(item){ return item.autoscript; }).indexOf(modelItem.autoscript);
          if (foundIndex > -1) {
            // update script position in formscriptlist and set _action attribute
            this.arrayMove(formScriptList, foundIndex, i);
          }
          
        }
      }
    },

    /**
     * Move element position into array 
     */
    arrayMove: function(arr, old_index, new_index) {
      if (new_index >= arr.length) {
          var k = new_index - arr.length + 1;
          while (k--) {
              arr.push(undefined);
          }
      }
      arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
    },

    /**
     * Fire request to fetch records
     */
  	requestAutoScripts: function() {
      return this.$.autoscriptCollection.refreshRecords();
  	},

  	/**
  	 * Submit update request
  	 * Return promise
  	 */
  	updateRecord: function(record) {
  	  var resource = this.$.inspectionFormResource;
  	  var responseProps = 'readconfirmation,audioguided,inspformscript{*}';

  	  resource.resourceUri = record.href;
  	  return resource.updateRecord(record, responseProps);
  	},

  	/**
  	 * Close button handler
  	 */
  	_close: function(event) {
  	  this.closeMe();
  	},

  	/**
  	 * Close modal host
  	 */
  	closeMe: function() {
  	  //this.owner.close();
      this.fire('cancel');
  	},

  	/**
     * Fire event to update record and close modal
     */
    saveMe: function(record) {
      this.fire('save', record);
    },

    /**
     * Listen to selection is made in available list
     */
  	_optionSelectedChanged: function(event) {

      if(this.$.optionsdatalist._selectedRecords.length && !this.readOnlyMode){
        this.$.addActions.removeAttribute('disabled');
      } else {
    	this.$.addActions.setAttribute('disabled', 'true');
      }
    },

    /**
     * Chosen datalist event listener
     */
    _selectedSelectedChanged: function() {
      // TODO
    },

    /**
     * Listen to reorder event in chosen datalist
     */
    _orderChanged: function(event) {
      var dataList = this.chosenAutoScripts;
      var scriptList = this.lightweightForm.inspformscript;

      if (!scriptList || this.readOnlyMode) {
        return;
      }

      // sync selectiondatalist list with inspformscript list
      this.reorderList(dataList, scriptList);
      this.setScriptsSequence();
      this._setHasChanged(this.verifyChanges());

    },

});
