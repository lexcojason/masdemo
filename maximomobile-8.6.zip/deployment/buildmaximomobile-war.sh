#!/bin/sh

# -----------------------------------------
# The following are required for runnig ant
# -----------------------------------------
export oldpath=$CLASSPATH
export JAVA_HOME=./../tools/java/jre
export ANT_HOME=./../tools/ant
export BUILD_DIR=./default

export CLASSPATH=.

if [ "$1" = "" ] ; then
	$ANT_HOME/bin/ant -buildfile ./buildmaximomobile-war.xml -Dmaximo.builddir=$BUILD_DIR
fi

if [ "$1" = "blueid" ] ; then
	$ANT_HOME/bin/ant -buildfile ./buildmaximomobile-war.xml -Dmaximo.builddir=$BUILD_DIR -Dmaximo.blueid=true
fi

export CLASSPATH=$oldpath