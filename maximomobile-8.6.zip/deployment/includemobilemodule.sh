#!/bin/sh

# -----------------------------------------
# The following are required for runnig ant
# -----------------------------------------
export oldpath=$CLASSPATH
export oldjava=$JAVA_HOME
export ANT_HOME=./../tools/ant
export TOOLS_HOME=./../tools/maximo
export MAXIMO_HOME=./../applications/maximo

if [ "$MAXIMO_JAVA" = "" ] ; then
	export JAVA_HOME=./../tools/java/jre
fi

# ------------------------------------------------------------

export BUILD_DIR=./default
export EAR_FILENAME=maximo.ear
export MAXIMO_PROPERTIES=maximo.properties

export CLASSPATH=.:$MAXIMO_HOME/businessobjects/classes:$MAXIMO_HOME/lib/jdom.jar:$TOOLS_HOME/classes:$TOOLS_HOME

$JAVA_HOME/bin/java  -classpath $CLASSPATH   psdi.tools.MergeWSDefinition -k. -t./../applications/maximo/meaweb/webmodule/WEB-INF

$JAVA_HOME/bin/java -classpath $CLASSPATH   psdi.tools.MaximoBuildEarTask -k.

# Save error code
MAX_ERRORBLD=$?


# If successfull , continue
if [ $MAX_ERRORBLD = 0 ] ;then
  export ANT_OPTS="$ANT_OPTS -Xmx1024M"
  $ANT_HOME/bin/ant  -buildfile ./includemobilemodule.xml -Dmaximo.builddir=$BUILD_DIR  -Dmaximo.basedir=./../applications/maximo -Dmaximo.earfile=$EAR_FILENAME -Dmaximo.properties=$MAXIMO_PROPERTIES $1
  MAX_ERRORBLD=$?
fi

export JAVA_HOME=$oldjava
export CLASSPATH=$oldpath
exit $MAX_ERRORBLD
